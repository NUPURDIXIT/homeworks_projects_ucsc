<?php
$sponsors_url=array('https://www.ahfc.us/pros/loans/loans-sponsors',
	'http://www.quickenloans.com/about/partner-company');
echo json_encode($sponsors_url);
?>