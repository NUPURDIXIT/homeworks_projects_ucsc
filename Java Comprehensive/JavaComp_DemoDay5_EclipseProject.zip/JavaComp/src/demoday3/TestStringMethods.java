package demoday3;

import java.awt.Point;
import java.util.Scanner;

public class TestStringMethods {

	public static void main(String[] args) {

		// Example#1
		String str1 = "Bineet";
		String str2 = "Bi";
		String str3 = "Bineeta";
		String str4 = "Bipins";
		String str5 = "Bimal";
		String str6 = "Bz";
		String str7 = "Ba";

		System.out.println(str1 + " " + str2 + " :" + str1.compareTo(str2)); // 3
		System.out.println(str1 + " " + str3 + " :" + str1.compareTo(str3)); // -1
		System.out.println(str1 + " " + str4 + " :" + str1.compareTo(str4)); // -2
		System.out.println(str1 + " " + str5 + " :" + str1.compareTo(str5)); // 1
		System.out.println(str1 + " " + str6 + " :" + str1.compareTo(str6)); // -17
		System.out.println(str1 + " " + str7 + " :" + str1.compareTo(str7)); // 8
		System.out.println(str1 + " " + str1 + " :" + str1.compareTo(str1)); // 0

		// Example#2
		String s1 = "Adam";
		String s2 = s1;
		if (s1 == s2) // ??
			System.out.println("s1: " + s1 + " s2: " + s2 + " is =");
		else
			System.out.println("s1: " + s1 + " s2: " + s2 + " is not =");

		// Example#3
		String s3 = "Elizabeth";
		String s4 = "Elizabeth";
		if (s3 == s4) // ??
			System.out.println("s3: " + s3 + " s4: " + s4 + " is =");
		else
			System.out.println("s4: " + s4 + " s4: " + s4 + " is not =");

		// Example#4
		String s5 = "Elizabeth";
		String s6 = "Elizabeth";
		s5 = "Elizabeth";
		s6 = "Elizabeth";
		if (s5 == s6) // ??
			System.out.println("s5: " + s5 + " s6: " + s6 + " is =");
		else
			System.out.println("s6: " + s5 + " s6: " + s6 + " is not =");

		// Example#5
		String S7 = new String("Elizabeth");
		String S8 = new String("Elizabeth");
		// S7="Elizabeth"; //what happens if we did this?
		// S8="Elizabeth";
		if (S7 == S8) // ??
			System.out.println("S7: " + S7 + " S8: " + S8 + " is =");
		else
			System.out.println("S7: " + S7 + " S8: " + S8 + " is not =");

		// Example#6
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter S10: ");
		String S10 = sc.next();
		System.out.print("Enter S11: ");
		String S11 = sc.next();

		if (S10 == S11) // ?? - case 1, different string, case 2 same string
			System.out.println("S10: " + S10 + " S11: " + S11 + " is =");
		else
			System.out.println("S10: " + S10 + " S11: " + S11 + " is not =");

		// Example#7
		String s12 = "OldString";
		String s13 = "OldString";

		if (s12 == s13) // ??
			System.out.println("s12: " + s12 + " s13: " + s13 + " is =");
		else
			System.out.println("s12: " + s12 + " s13: " + s13 + " is not =");

		System.out.print("Enter s12: ");
		s12 = sc.next();
		System.out.print("Enter s13: ");
		s13 = sc.next();

		if (s12 == s13) // ?? Say you wrote "OldString" for both
			System.out.println("s12: " + s12 + " s13: " + s13 + " is =");
		else
			System.out.println("s12: " + s12 + " s13: " + s13 + " is not =");

		// Example#8
		String s14 = "OldString";
		String s15 = s14.toUpperCase();

		if (s14 == s15) // ??
			System.out.println("s14: " + s14 + " s15: " + s15 + " is =");
		else if (s14.equals(s15))
			System.out.println("s14: " + s14 + " s15: " + s15 + " is equal");
		else
			System.out
					.println("s14: " + s14 + " s15: " + s15 + " is not equal");

		// Example#9
		String s16 = "Hello ";
		String s17 = s16;
		s16 += "welcome to the class!";

		if (s16 == s17) // ??
			System.out.println("s16: " + s16 + " s17: " + s17 + " is =");
		else if (s16.equals(s17))
			System.out.println("s16: " + s16 + " s17: " + s17 + " is equal");
		else
			System.out
					.println("s16: " + s16 + " s17: " + s17 + " is not equal");
		// ?? What s1 holds, and what s2 holds? And why?
	}
}