package demoday4.product;
public interface Printable
{
    public abstract void print(); 
}