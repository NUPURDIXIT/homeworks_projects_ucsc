package demoday3;
import java.awt.Point;

//pass by reference vs. pass by value
public class Demo_PassReferenceValue {
	// swaps two string references
	private static int count = 0;
	private static void swapValue(String one, String two) {
		String tempStr = one;
		one = two;
		two = tempStr;
	}

	// swaps the two point references
	private static void swapValue(Point point1, Point point2) {
		Point tempPoint = point1;
		point1 = point2;
		point2 = tempPoint;
		System.out.println("Inside swapValue - Points after swap, point1+ " 
                + point1 + " point2: " + point2);
}

	// swaps the x,y co-ordinate of a point reference
	private static void swapValue(Point p1) {
		int temp = p1.x;
		p1.x = p1.y;
		p1.y = temp;
	}

	// swaps two primitive integer
	private static void swapValue(int a, int b) {
		int temp = a;
		a = b;
		b = temp;
	}

	public static void main(String[] args) {
		int x = 15, y = 20, temp;
		System.out.println("Before swap x: " + x + " y: " + y);
		temp = x;
		x = y;
		y = temp;
		System.out.println("Local swap x: " + x + " y: " + y);

		x = 15;
		y = 20; // reset the value
		swapValue(x, y);
		System.out.println("After swap method call x: " + x + " y: " + y);

		//let us check if we can swap a reference
		x = 15;
		y = 20; // reset the value
		Point p1 = new Point(x, y);
		Point p2 = new Point(1, 3);
		
		System.out.println("Before swapValue method call - p1 " 
                + p1 + " p2: " + p2);
		swapValue(p1, p2);
		System.out.println("After swapValue method call - p1 " 
                + p1 + " p2: " + p2);
		
		//let us check if we can swap values in the reference
		x = 15;
		y = 20; // reset the values
		Point p = new Point(x, y);
		System.out.println("Before swap method call Point p.x: " + p.x + " p.y: " + p.y);
		swapValue(p);
		System.out.println("After swap method call Point p.x: " + p.x + " p.y: " + p.y);

		// How about the strings, that is reference
		String str1 = "John";
		String str2 = "Elizabeth";

		String tempStr = str1;
		System.out.println("Before local swap String str1: " + str1 + " str2: " + str2);
		str1 = str2;
		str2 = tempStr;
		System.out.println("After local swap String str1: " + str1 + " str2: " + str2);

		str1 = "John";      //reset
		str2 = "Elizabeth";
		swapValue(str1, str2);
		System.out
				.println("After swap method call String str1: " + str1 + " str2: " + str2);

		//so what is conclusion?
		//Java is always pass by value.  Even when you 
		//pass a reference.  When you pass reference, you work with original
		//so, you could change the value in them (e.g. point.x, and point.y) but,
		//not able to swap the reference themselves
	}
}
