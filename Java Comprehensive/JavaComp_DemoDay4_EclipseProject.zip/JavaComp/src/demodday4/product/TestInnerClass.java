package demodday4.product;
import java.awt.*;
import java.awt.event.*;

class TestInnerClass extends Frame implements ActionListener {
	// constructor
	public TestInnerClass(String s) {
		super(s);
		setLayout(new FlowLayout());
		Button pushButton = new Button("Go Ahead, Click Me");
		add(pushButton);
		pushButton.addActionListener(this); 

	    //declare a inner class	
		class InnerClass_WA extends WindowAdapter {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		}
		InnerClass_WA icWA = new InnerClass_WA();
		addWindowListener(icWA);

		/*alternatively you can create inner anonymous class		
		addWindowListener(new WindowAdapter() {
			//inner anonymous class
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		}); 
		*/
	}

	// define action for Button press
	public void actionPerformed(ActionEvent event) {
		if (event.getActionCommand().equals("Go Ahead, Click Me")) {
			System.out.println("ouch!");
		}
	}

	public static void main(String[] args) {
		TestInnerClass screen = new TestInnerClass("Graphic Example");
		screen.setSize(550, 200);
		screen.setVisible(true);
	}
}

